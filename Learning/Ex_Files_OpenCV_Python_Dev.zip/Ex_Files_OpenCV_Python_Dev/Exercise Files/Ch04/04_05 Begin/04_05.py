import numpy as np
import cv2

img = cv2.imread("faces.jpeg",1)