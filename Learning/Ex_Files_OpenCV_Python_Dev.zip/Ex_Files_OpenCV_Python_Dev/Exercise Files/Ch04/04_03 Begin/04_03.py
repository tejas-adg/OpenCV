import numpy as np
import cv2

template = cv2.imread('template.jpg',0)
frame = cv2.imread("players.jpg",0)