import numpy as np
import cv2

image = cv2.imread("thresh.jpg")