import numpy as np
import cv2

img = cv2.imread("players.jpg",1)