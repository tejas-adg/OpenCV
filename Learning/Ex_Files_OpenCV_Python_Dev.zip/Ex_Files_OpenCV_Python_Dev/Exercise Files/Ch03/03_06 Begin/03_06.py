import numpy as np
import cv2

img = cv2.imread('detect_blob.png',1)