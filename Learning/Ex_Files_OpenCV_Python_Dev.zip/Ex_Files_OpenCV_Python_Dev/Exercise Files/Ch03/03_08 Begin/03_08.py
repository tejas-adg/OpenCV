import numpy as np
import cv2

img = cv2.imread("tomatoes.jpg",1)